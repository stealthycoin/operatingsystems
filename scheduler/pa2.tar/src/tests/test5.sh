#!/bin/sh

time nice -n 80 ./cpu_bound &
time nice -n 80 ./IO_bound.sh &
