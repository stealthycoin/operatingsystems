#!/bin/sh
dd if=/dev/urandom of=/dev/null count=250000
